({
    doInit : function(component, event, helper) {
        var action = component.get("c.showFields");
        action.setParams({
            selectedObject : component.get("v.selectedObject2")
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            if (component.isValid() && state === "SUCCESS") {
                component.set("v.FieldList", response.getReturnValue());
            }
        });
        $A.enqueueAction(action);
    },
    
    addFieldClick : function(component, event, helper){
        var CriteriaObj = component.get("v.CriteriaObj");
        var selectedField = component.find("FieldList").get("v.value");
        CriteriaObj.Field_API_Name__c = selectedField;
        if($A.util.isEmpty(CriteriaObj.Field_API_Name__c) || $A.util.isUndefined(CriteriaObj.Field_API_Name__c)){
            alert('Field Change is required');
            return;
        }            
        var table = document.getElementById("myTable");
        var newRow = table.insertRow(table.rows.length);
        
        var cell1 = newRow.insertCell(0);
        var element1 = helper.createElement(component,"label","label","slds-truncated",selectedField);                
        cell1.appendChild(element1);
        
        var cell2 = newRow.insertCell(1);
        var element2 = helper.createElement(component,"select","select","slds-select slds-selected-common",'');                
        cell2.appendChild(element2);
        
        var cell3 = newRow.insertCell(2);
        var element3 = helper.createElement(component,"input","text","slds-input",''); 
        cell3.appendChild(element3);
        
        var cell4 = newRow.insertCell(3);
        var element4 = helper.createElement(component,"select","select","slds-select slds-selected",''); 
        cell4.appendChild(element4);
        
        var cell5 = newRow.insertCell(4);
        var element5 = helper.createElement(component,"input","button","btn btn-default","Delete");
        element5.onclick = function() {
            table.deleteRow(this.parentNode.parentNode.rowIndex);
        };
        cell5.appendChild(element5);
    },
    
    saveCriteria : function(component, event, helper){
        var sobjType2 = component.get("v.sobjType");
        var criOrder2 = component.get("v.criOrder");
        var fldApiName2 = component.get("v.fldApiName");
        var opr2 = component.get("v.opr");
        var fldVal2 = component.get("v.fldVal");
        var assignUsrQue2 = component.get("v.assignUsrQue");
        var assignmentName2 = component.get("v.assignmentName2");
        var action = component.get("c.createCriteriaRecord");
        var tableId = document.getElementById("myTable");
        var rowCount = tableId.rows.length;
        var opertor = document.getElementsByClassName("slds-select slds-selected-common");
        var assign = document.getElementsByClassName("slds-select slds-selected");
        for (var i = 0; i < rowCount; i++){
            if(i == (rowCount-1))
            {
                break;
            }
            else{
                var opertorTempo = opertor[i].options[opertor[i].selectedIndex];
                var selectOperator = opertorTempo.value;
                var assignTempo = assign[i].options[assign[i].selectedIndex];
                var selectAssign = assignTempo.value;
                var fieldApiName = document.getElementsByClassName("slds-truncated")[i].innerHTML;
                var fieldValue = document.getElementsByClassName("slds-input")[i+1].value;
            }
            criOrder2.push((i+1).toString());
            fldApiName2.push(fieldApiName);
            opr2.push(selectOperator);
            fldVal2.push(fieldValue);
            assignUsrQue2.push(selectAssign);
        }
        action.setParams({
            assignmentName : assignmentName2,
            criOrderf : criOrder2,
            fldApiNamef : fldApiName2,
            oprf : opr2,
            fldValf :fldVal2,
            assignUsrQuef : assignUsrQue2
        });
        action.setCallback(this,function(a){
            var state = a.getState();
            if(state == "SUCCESS"){
                alert('Criteria added Successfully');
            } 
            else if(state == "ERROR"){
                alert('Error in calling server side action');
            }
        });
        $A.enqueueAction(action);
        
        var evt = $A.get("e.force:navigateToComponent");
        evt.setParams({
            componentDef :"c:CustomAssignmentRuleComponent",
            componentAttributes: {
            }
        });
        evt.fire();
    },
})