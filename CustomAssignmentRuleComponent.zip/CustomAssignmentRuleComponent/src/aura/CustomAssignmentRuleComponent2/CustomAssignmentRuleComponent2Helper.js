({
    createElement : function (comp,type,element_type, className, text ) 
    {
        var element = document.createElement(type);
        element.type = element_type;
        element.className = className;
        if(element_type == "button")
            element.value = text;  
        else if(element_type == "select" && className == "slds-select slds-selected-common")
        {
            var action = comp.get("c.getOperatorList");
            action.setCallback(this,function(a){
                var state = a.getState();
                if(state == "SUCCESS"){
                    var lstOperator = a.getReturnValue();
                    for(var i=0 ; i < lstOperator.length; i++)
                    {
                        var option = document.createElement('option');
                        option.text = lstOperator[i];
                        element.add(option,i);
                    }
                } 
                else if(state == "ERROR"){
                    alert('Error in calling server side action');
                }
            });
            $A.enqueueAction(action);           
        }
            else if(element_type == "text"){
                console.log('element: '+element +' element.type: '+element.type);
            }
                else if(element_type == "select" && className == "slds-select slds-selected")
                {
                    var action = comp.get("c.getUserQueueList");
                    action.setCallback(this,function(a){
                        var state = a.getState();
                        if(state == "SUCCESS"){
                            var lstUser = a.getReturnValue();
                            for(var i=0 ; i < lstUser.length; i++)
                            {
                                var option = document.createElement('option');
                                option.text = lstUser[i];
                                element.add(option,i);
                            }
                        } 
                        else if(state == "ERROR"){
                            alert('Error in calling server side action');
                        }
                    });
                    $A.enqueueAction(action);           
                }        
                    else
                        element.innerHTML = text;
        return element;
    },
})