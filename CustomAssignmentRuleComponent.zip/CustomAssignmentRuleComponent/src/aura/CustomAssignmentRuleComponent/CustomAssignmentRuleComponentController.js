({
    doInit : function(component, event, helper) {
        var action = component.get("c.newList");
        action.setCallback(this, function(response){
            var state = response.getState();
            if (component.isValid() && state == "SUCCESS") {
                component.set("v.ObjectList", response.getReturnValue());
            }
        });
        $A.enqueueAction(action);
    },
    onSelectChange : function(component, event, helper) {
        var selected = component.find("objectlist").get("v.value");
    },
    
    navigateToMyComponent : function(component, event, helper) {
        var AssignComponent = component.get("v.AssignComponent");
        var selected = component.find("objectlist").get("v.value");
        var assignmentName = component.get("v.assignmentRuleName");
        AssignComponent.Assignment_Rule_Name__c = assignmentName;
        AssignComponent.Object_Name__c = selected;
        if($A.util.isEmpty(AssignComponent.Assignment_Rule_Name__c) || $A.util.isUndefined(AssignComponent.Assignment_Rule_Name__c)){
            alert('Assignment Rule Name is Required');
            return;
        }            
        if($A.util.isEmpty(AssignComponent.Object_Name__c) || $A.util.isUndefined(AssignComponent.Object_Name__c)){
            alert('Object Change is Required');
            return;
        }
        var action = component.get("c.createGenDetails");
        action.setParams({
            assignmentRuleName : assignmentName,
            selectedObject : selected
        });
        action.setCallback(this,function(a){
            var state = a.getState();
            var data = a.getReturnValue();
            if(state == "SUCCESS"){
                if(data == true){
                    var newAssignComponent = {'sobjectType': 'AssignComponent__c',
                                              'Assignment_Rule_Name__c': '',
                                              'Object_Name__c': ''
                                             };
                    component.set("v.AssignComponent",newAssignComponent);
                    alert('Record is Created Successfully');
                    var evt = $A.get("e.force:navigateToComponent");
                    evt.setParams({
                        componentDef :"c:CustomAssignmentRuleComponent2",
                        componentAttributes: {
                            selectedObject2 : selected,
                            assignmentName2 : assignmentName
                        }
                    });
                    evt.fire();
                }
                else if(data == false){
                    alert('Assignment Rule is already created on this Object');
                }
            }
            else if(state == "ERROR"){
                alert('Error in calling server side action');
            }
        });
        $A.enqueueAction(action);
    },
})